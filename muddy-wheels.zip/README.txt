1. Run this command in Terminal to run the Main Program: sh compilerun.sh

Muddy Wheels is a simple travel application that allows users to book a flight or rent a car. 
The language used is Java, and the program is text-based.

Alvin, Sean, Ula.
Spring 2024.